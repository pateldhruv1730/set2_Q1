package com.example.a3addnum

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btn: Button = findViewById(R.id.btnans)
        var ed1:EditText = findViewById(R.id.edno1)
        var ed2:EditText = findViewById(R.id.edno2)
        var tvan:TextView = findViewById(R.id.tvans)
        btn.setOnClickListener {

            var n1 = ed1.text.toString().toInt()
            var n2 = ed2.text.toString().toInt()
                var ans = n1 + n2
        tvan.text = ans.toString()
        }
    }
}